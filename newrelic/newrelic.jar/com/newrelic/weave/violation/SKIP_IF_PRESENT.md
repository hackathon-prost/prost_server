## SKIP_IF_PRESENT ##

###Description###

This violation was raised because the class was defined with @SkipIfPresent and it was found on the classpath.


###No Example###