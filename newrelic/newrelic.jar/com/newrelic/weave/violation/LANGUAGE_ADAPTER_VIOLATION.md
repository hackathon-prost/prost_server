## LANGUAGE_ADAPTER_VIOLATION ##

###Description###

This violation was raised by a non-java weaver (e.g. Scala). Consult the documentation for your language adapter.

###No Example###